from .cognex_robotraconteur_driver import main

main()